# Finance CloudOps (base project)

A simple FinOps starter: track cloud costs, set team budgets, spot cost spikes, forecast month-end spend.

## Run
    pip install -r requirements.txt
    python app.py
Open http://127.0.0.1:5000 and click **Load demo data**.

## API
| Method | Endpoint | Purpose |
|---|---|---|
| POST | /api/costs | add a cost record (day, provider, service, team, amount) |
| GET  | /api/costs | latest 200 records |
| POST | /api/costs/import | upload CSV (day,provider,service,team,amount) |
| PUT  | /api/budgets/<team> | set `{ "monthly_limit": 2000 }` |
| GET  | /api/budgets | budget usage + OK/WARNING/OVER |
| GET  | /api/summary | totals by service / team / provider / day |
| GET  | /api/anomalies | days with spend > mean + 2σ |
| GET  | /api/forecast | month-end projection |
| POST | /api/seed | load demo data |

## Next steps
Pull real data (AWS Cost Explorer / Azure Cost Mgmt / GCP Billing export), add auth, Postgres, Slack/email budget alerts, tagging-compliance checks, Docker + CI/CD.
